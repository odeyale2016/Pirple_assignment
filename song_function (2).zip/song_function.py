def Genre():
    genre="Don Jazz"
    return genre


def Artist():
    artist="Davido Michael"
    return artist


def Year():
    year="2020"
    return year

def myBoolVar():
    tVal=True
    return tVal

var1=Genre()
var2=Artist()
var3=Year()
var4=myBoolVar()
print(var1)
print(var2)
print(var3)
print(var4)