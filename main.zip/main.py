'''
This Program is written to display the attributes of the latest song in this year
'''
artist="Don Jazz"           # This is the name of the artist of the song
year="2020"                 # this is the year the song released
album="My Song"             # This is the name of the album for the song
genre="Jazz"                # This is the name of the genre of the song
DurationInSecond=350        # This is the total duration of the song in seconds
amount_sold=459.00          # This is the amount of the copy of the song in dollar
qty_available=6000          # No of available copies
title="My first sucess song"# This is the title of the song
print(artist)
print(year)
print(album)
print(genre)
print(DurationInSecond)
print(amount_sold)
print(qty_available)
print(title)