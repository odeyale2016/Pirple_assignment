# VacationSpots = ["London", "Paris", "New York", "Utah", "Iceland"]
# VacationFile = open("VacationPlaces", "w")

# for Spots in VacationSpots:
# 	VacationFile.write(Spots+"\n")

# VacationFile.close() 

# VacationFile= open("VacationPlaces", "r")
# TheWholeFile = VacationFile.read()
# print(TheWholeFile)
# VacationFile.close()
# VacationFile=open("VacationPlaces", "r")

# FirstLine = VacationFile.readline()
# print(FirstLine)
# SecondLine = VacationFile.readline()
# print(SecondLine)
# for line in VacationFile:
#     print(line, end="") 
# VacationFile.close()
# FinalSpot = "Thailand\n"

# VacationFile = open("VacationPlaces", "a")
# VacationFile.write(FinalSpot)
# VacationFile.close()
# VacationFile=open("VacationPlaces","r")
# for line in VacationFile:
# 	print(line, end="")
# VacationFile.close()

# with open("VacationPlaces","r") as VacationFile:
# 	for line in VacationFile:
# 		print(line)

# TIC-TOC FILE CODES
